# Changelog

## [m1]-2020-10-30

---

### Added1

* structure of players and card  using array

* single function to draw and play one card

## [m2]-2020-11-03

---

### Added2

* a main mode and a demo mode all using array

* using comment line to control

## [m3]-2020-11-14

---

### Added3

* pointers to replace array

* play 2 cards in a round

* linked list and dynamic array

* split into different file
