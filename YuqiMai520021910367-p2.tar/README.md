# P2

## by Mai Yuqi 520021910367

### content table

---

* how to play

* features

### how to play

---

* download all the file into a folder

* compile all the c file by **gcc main.c linkedlist.c game.c mode.c card.c -o main** and **./main**

* can use command line input

### features

---

* able to play 2 cards in a turn
* able to run on Windows and MacOS and Linux
* need to press "enter" at the end of one turn and one round
