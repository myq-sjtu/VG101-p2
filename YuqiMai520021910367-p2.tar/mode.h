#ifndef MODE_H
#define MODE_H

#include"game.h"

void mode(int nofcard,int nofplayer,int nofdeck,int nofround,FILE *fp,int mode);

#endif
